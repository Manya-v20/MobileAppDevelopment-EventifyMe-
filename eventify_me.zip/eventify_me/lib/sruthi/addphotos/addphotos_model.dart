import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'addphotos_widget.dart' show AddphotosWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddphotosModel extends FlutterFlowModel<AddphotosWidget> {
  ///  Local state fields for this component.

  List<String> addphotos = [];
  void addToAddphotos(String item) => addphotos.add(item);
  void removeFromAddphotos(String item) => addphotos.remove(item);
  void removeAtIndexFromAddphotos(int index) => addphotos.removeAt(index);
  void insertAtIndexInAddphotos(int index, String item) =>
      addphotos.insert(index, item);
  void updateAddphotosAtIndex(int index, Function(String) updateFn) =>
      addphotos[index] = updateFn(addphotos[index]);

  ///  State fields for stateful widgets in this component.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode3;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  bool isDataUploading_uploadDataWjq = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadDataWjq = [];
  List<String> uploadedFileUrls_uploadDataWjq = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();

    textFieldFocusNode3?.dispose();
    textController3?.dispose();
  }
}
