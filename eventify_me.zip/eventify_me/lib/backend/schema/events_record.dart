import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EventsRecord extends FirestoreRecord {
  EventsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "club_icon" field.
  String? _clubIcon;
  String get clubIcon => _clubIcon ?? '';
  bool hasClubIcon() => _clubIcon != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "club_name" field.
  String? _clubName;
  String get clubName => _clubName ?? '';
  bool hasClubName() => _clubName != null;

  // "poster" field.
  String? _poster;
  String get poster => _poster ?? '';
  bool hasPoster() => _poster != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  bool hasDate() => _date != null;

  // "name_conatct" field.
  String? _nameConatct;
  String get nameConatct => _nameConatct ?? '';
  bool hasNameConatct() => _nameConatct != null;

  void _initializeFields() {
    _description = snapshotData['description'] as String?;
    _clubIcon = snapshotData['club_icon'] as String?;
    _name = snapshotData['name'] as String?;
    _clubName = snapshotData['club_name'] as String?;
    _poster = snapshotData['poster'] as String?;
    _location = snapshotData['location'] as String?;
    _date = snapshotData['date'] as String?;
    _nameConatct = snapshotData['name_conatct'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('events');

  static Stream<EventsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EventsRecord.fromSnapshot(s));

  static Future<EventsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EventsRecord.fromSnapshot(s));

  static EventsRecord fromSnapshot(DocumentSnapshot snapshot) => EventsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EventsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EventsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EventsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EventsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEventsRecordData({
  String? description,
  String? clubIcon,
  String? name,
  String? clubName,
  String? poster,
  String? location,
  String? date,
  String? nameConatct,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'description': description,
      'club_icon': clubIcon,
      'name': name,
      'club_name': clubName,
      'poster': poster,
      'location': location,
      'date': date,
      'name_conatct': nameConatct,
    }.withoutNulls,
  );

  return firestoreData;
}

class EventsRecordDocumentEquality implements Equality<EventsRecord> {
  const EventsRecordDocumentEquality();

  @override
  bool equals(EventsRecord? e1, EventsRecord? e2) {
    return e1?.description == e2?.description &&
        e1?.clubIcon == e2?.clubIcon &&
        e1?.name == e2?.name &&
        e1?.clubName == e2?.clubName &&
        e1?.poster == e2?.poster &&
        e1?.location == e2?.location &&
        e1?.date == e2?.date &&
        e1?.nameConatct == e2?.nameConatct;
  }

  @override
  int hash(EventsRecord? e) => const ListEquality().hash([
        e?.description,
        e?.clubIcon,
        e?.name,
        e?.clubName,
        e?.poster,
        e?.location,
        e?.date,
        e?.nameConatct
      ]);

  @override
  bool isValidKey(Object? o) => o is EventsRecord;
}
