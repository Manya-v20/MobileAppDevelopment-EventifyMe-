// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GalleryimagesStruct extends FFFirebaseStruct {
  GalleryimagesStruct({
    String? eventname,
    DateTime? datetime,
    List<String>? photos,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _eventname = eventname,
        _datetime = datetime,
        _photos = photos,
        super(firestoreUtilData);

  // "eventname" field.
  String? _eventname;
  String get eventname => _eventname ?? '';
  set eventname(String? val) => _eventname = val;

  bool hasEventname() => _eventname != null;

  // "datetime" field.
  DateTime? _datetime;
  DateTime? get datetime => _datetime;
  set datetime(DateTime? val) => _datetime = val;

  bool hasDatetime() => _datetime != null;

  // "photos" field.
  List<String>? _photos;
  List<String> get photos => _photos ?? const [];
  set photos(List<String>? val) => _photos = val;

  void updatePhotos(Function(List<String>) updateFn) {
    updateFn(_photos ??= []);
  }

  bool hasPhotos() => _photos != null;

  static GalleryimagesStruct fromMap(Map<String, dynamic> data) =>
      GalleryimagesStruct(
        eventname: data['eventname'] as String?,
        datetime: data['datetime'] as DateTime?,
        photos: getDataList(data['photos']),
      );

  static GalleryimagesStruct? maybeFromMap(dynamic data) => data is Map
      ? GalleryimagesStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'eventname': _eventname,
        'datetime': _datetime,
        'photos': _photos,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'eventname': serializeParam(
          _eventname,
          ParamType.String,
        ),
        'datetime': serializeParam(
          _datetime,
          ParamType.DateTime,
        ),
        'photos': serializeParam(
          _photos,
          ParamType.String,
          isList: true,
        ),
      }.withoutNulls;

  static GalleryimagesStruct fromSerializableMap(Map<String, dynamic> data) =>
      GalleryimagesStruct(
        eventname: deserializeParam(
          data['eventname'],
          ParamType.String,
          false,
        ),
        datetime: deserializeParam(
          data['datetime'],
          ParamType.DateTime,
          false,
        ),
        photos: deserializeParam<String>(
          data['photos'],
          ParamType.String,
          true,
        ),
      );

  @override
  String toString() => 'GalleryimagesStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is GalleryimagesStruct &&
        eventname == other.eventname &&
        datetime == other.datetime &&
        listEquality.equals(photos, other.photos);
  }

  @override
  int get hashCode => const ListEquality().hash([eventname, datetime, photos]);
}

GalleryimagesStruct createGalleryimagesStruct({
  String? eventname,
  DateTime? datetime,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    GalleryimagesStruct(
      eventname: eventname,
      datetime: datetime,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

GalleryimagesStruct? updateGalleryimagesStruct(
  GalleryimagesStruct? galleryimages, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    galleryimages
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addGalleryimagesStructData(
  Map<String, dynamic> firestoreData,
  GalleryimagesStruct? galleryimages,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (galleryimages == null) {
    return;
  }
  if (galleryimages.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && galleryimages.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final galleryimagesData =
      getGalleryimagesFirestoreData(galleryimages, forFieldValue);
  final nestedData =
      galleryimagesData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = galleryimages.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getGalleryimagesFirestoreData(
  GalleryimagesStruct? galleryimages, [
  bool forFieldValue = false,
]) {
  if (galleryimages == null) {
    return {};
  }
  final firestoreData = mapToFirestore(galleryimages.toMap());

  // Add any Firestore field values
  galleryimages.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getGalleryimagesListFirestoreData(
  List<GalleryimagesStruct>? galleryimagess,
) =>
    galleryimagess
        ?.map((e) => getGalleryimagesFirestoreData(e, true))
        .toList() ??
    [];
