import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsercreateaccountRecord extends FirestoreRecord {
  UsercreateaccountRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "password" field.
  String? _password;
  String get password => _password ?? '';
  bool hasPassword() => _password != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "collegename" field.
  String? _collegename;
  String get collegename => _collegename ?? '';
  bool hasCollegename() => _collegename != null;

  // "useroradmin" field.
  String? _useroradmin;
  String get useroradmin => _useroradmin ?? '';
  bool hasUseroradmin() => _useroradmin != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _password = snapshotData['password'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _collegename = snapshotData['collegename'] as String?;
    _useroradmin = snapshotData['useroradmin'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _photoUrl = snapshotData['photo_url'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('usercreateaccount');

  static Stream<UsercreateaccountRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsercreateaccountRecord.fromSnapshot(s));

  static Future<UsercreateaccountRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => UsercreateaccountRecord.fromSnapshot(s));

  static UsercreateaccountRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UsercreateaccountRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsercreateaccountRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsercreateaccountRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsercreateaccountRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsercreateaccountRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsercreateaccountRecordData({
  String? email,
  String? password,
  String? displayName,
  String? phoneNumber,
  String? collegename,
  String? useroradmin,
  String? uid,
  DateTime? createdTime,
  String? photoUrl,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'password': password,
      'display_name': displayName,
      'phone_number': phoneNumber,
      'collegename': collegename,
      'useroradmin': useroradmin,
      'uid': uid,
      'created_time': createdTime,
      'photo_url': photoUrl,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsercreateaccountRecordDocumentEquality
    implements Equality<UsercreateaccountRecord> {
  const UsercreateaccountRecordDocumentEquality();

  @override
  bool equals(UsercreateaccountRecord? e1, UsercreateaccountRecord? e2) {
    return e1?.email == e2?.email &&
        e1?.password == e2?.password &&
        e1?.displayName == e2?.displayName &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.collegename == e2?.collegename &&
        e1?.useroradmin == e2?.useroradmin &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.photoUrl == e2?.photoUrl;
  }

  @override
  int hash(UsercreateaccountRecord? e) => const ListEquality().hash([
        e?.email,
        e?.password,
        e?.displayName,
        e?.phoneNumber,
        e?.collegename,
        e?.useroradmin,
        e?.uid,
        e?.createdTime,
        e?.photoUrl
      ]);

  @override
  bool isValidKey(Object? o) => o is UsercreateaccountRecord;
}
