import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegisteredmemRecord extends FirestoreRecord {
  RegisteredmemRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "usn" field.
  String? _usn;
  String get usn => _usn ?? '';
  bool hasUsn() => _usn != null;

  // "phnno" field.
  String? _phnno;
  String get phnno => _phnno ?? '';
  bool hasPhnno() => _phnno != null;

  // "dept" field.
  String? _dept;
  String get dept => _dept ?? '';
  bool hasDept() => _dept != null;

  // "year" field.
  String? _year;
  String get year => _year ?? '';
  bool hasYear() => _year != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _usn = snapshotData['usn'] as String?;
    _phnno = snapshotData['phnno'] as String?;
    _dept = snapshotData['dept'] as String?;
    _year = snapshotData['year'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('registeredmem')
          : FirebaseFirestore.instance.collectionGroup('registeredmem');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('registeredmem').doc(id);

  static Stream<RegisteredmemRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegisteredmemRecord.fromSnapshot(s));

  static Future<RegisteredmemRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RegisteredmemRecord.fromSnapshot(s));

  static RegisteredmemRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegisteredmemRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegisteredmemRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegisteredmemRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegisteredmemRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegisteredmemRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegisteredmemRecordData({
  String? name,
  String? usn,
  String? phnno,
  String? dept,
  String? year,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'usn': usn,
      'phnno': phnno,
      'dept': dept,
      'year': year,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegisteredmemRecordDocumentEquality
    implements Equality<RegisteredmemRecord> {
  const RegisteredmemRecordDocumentEquality();

  @override
  bool equals(RegisteredmemRecord? e1, RegisteredmemRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.usn == e2?.usn &&
        e1?.phnno == e2?.phnno &&
        e1?.dept == e2?.dept &&
        e1?.year == e2?.year;
  }

  @override
  int hash(RegisteredmemRecord? e) =>
      const ListEquality().hash([e?.name, e?.usn, e?.phnno, e?.dept, e?.year]);

  @override
  bool isValidKey(Object? o) => o is RegisteredmemRecord;
}
