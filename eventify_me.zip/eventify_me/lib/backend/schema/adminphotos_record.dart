import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AdminphotosRecord extends FirestoreRecord {
  AdminphotosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "eventname" field.
  String? _eventname;
  String get eventname => _eventname ?? '';
  bool hasEventname() => _eventname != null;

  // "photos1" field.
  List<String>? _photos1;
  List<String> get photos1 => _photos1 ?? const [];
  bool hasPhotos1() => _photos1 != null;

  // "startdate" field.
  String? _startdate;
  String get startdate => _startdate ?? '';
  bool hasStartdate() => _startdate != null;

  // "enddate" field.
  String? _enddate;
  String get enddate => _enddate ?? '';
  bool hasEnddate() => _enddate != null;

  void _initializeFields() {
    _eventname = snapshotData['eventname'] as String?;
    _photos1 = getDataList(snapshotData['photos1']);
    _startdate = snapshotData['startdate'] as String?;
    _enddate = snapshotData['enddate'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('adminphotos');

  static Stream<AdminphotosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AdminphotosRecord.fromSnapshot(s));

  static Future<AdminphotosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => AdminphotosRecord.fromSnapshot(s));

  static AdminphotosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AdminphotosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AdminphotosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AdminphotosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AdminphotosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AdminphotosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAdminphotosRecordData({
  String? eventname,
  String? startdate,
  String? enddate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'eventname': eventname,
      'startdate': startdate,
      'enddate': enddate,
    }.withoutNulls,
  );

  return firestoreData;
}

class AdminphotosRecordDocumentEquality implements Equality<AdminphotosRecord> {
  const AdminphotosRecordDocumentEquality();

  @override
  bool equals(AdminphotosRecord? e1, AdminphotosRecord? e2) {
    const listEquality = ListEquality();
    return e1?.eventname == e2?.eventname &&
        listEquality.equals(e1?.photos1, e2?.photos1) &&
        e1?.startdate == e2?.startdate &&
        e1?.enddate == e2?.enddate;
  }

  @override
  int hash(AdminphotosRecord? e) => const ListEquality()
      .hash([e?.eventname, e?.photos1, e?.startdate, e?.enddate]);

  @override
  bool isValidKey(Object? o) => o is AdminphotosRecord;
}
