import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBf3zy0XSIYFaDMla5OoVguYorGTcA6hZg",
            authDomain: "eventify-me-otz3dm.firebaseapp.com",
            projectId: "eventify-me-otz3dm",
            storageBucket: "eventify-me-otz3dm.appspot.com",
            messagingSenderId: "457720725018",
            appId: "1:457720725018:web:00bde456cacdcea5561ba3"));
  } else {
    await Firebase.initializeApp();
  }
}
