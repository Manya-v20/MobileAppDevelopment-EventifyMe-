import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class AdmingalleryphotosCall {
  static Future<ApiCallResponse> call({
    String? key = '',
    String? action = '',
    List<FFUploadedFile>? sourceList,
  }) async {
    final source = sourceList ?? [];

    return ApiManager.instance.makeApiCall(
      callName: 'admingalleryphotos',
      apiUrl: 'https://freeimage.host/api/1/upload',
      callType: ApiCallType.POST,
      headers: {},
      params: {
        'key': key,
        'action': action,
        'source': source,
      },
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GenTokenCall {
  static Future<ApiCallResponse> call({
    String? orderId = '',
    String? amount = '',
  }) async {
    final ffApiRequestBody = '''
{
  "orderId": "${orderId}",
  "orderAmount": "${amount}",
  "orderCurrency": "INR"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'genToken',
      apiUrl: 'https://test.cashfree.com/api/v2/cftoken/order',
      callType: ApiCallType.POST,
      headers: {
        'x-client-id': 'CF10264867CQC15G0PRSDS73C1GBV0',
        'x-client-secret':
            'cfsk_ma_test_2dc341c6109af8571f2e131c52731905_d41712ca',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
