import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'tos_model.dart';
export 'tos_model.dart';

class TosWidget extends StatefulWidget {
  const TosWidget({super.key});

  static String routeName = 'tos';
  static String routePath = '/tos';

  @override
  State<TosWidget> createState() => _TosWidgetState();
}

class _TosWidgetState extends State<TosWidget> {
  late TosModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TosModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Terms of Service',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  font: GoogleFonts.outfit(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                  ),
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                width: 392.0,
                height: 798.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Text(
                  '**Terms and Conditions**\n**1. Acceptance of Terms**\nBy accessing or using the App, you agree to be bound by these Terms. If you do not agree to these Terms, you may not access or use the App.\n**2. User Accounts**\na. To access certain features of the App, you may be required to create an account. You agree to provide accurate and complete information when creating your account and to update such information promptly if there are any changes.\nb. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account.\n**3. Use of the App**\na. You may use the App only for lawful purposes and in accordance with these Terms. You agree not to use the App:\n   i. In any way that violates any applicable law or regulation.\n   ii. To engage in any conduct that restricts or inhibits anyone\'s use or enjoyment of the App, or which may harm the Company or its users.\nb. You acknowledge and agree that the Company may access, preserve, and disclose your account information if required to do so by law or in a good faith belief that such access, preservation, or disclosure is reasonably necessary to:\n i. Comply with legal process. \n   ii. Enforce these Terms.   \n   iii. Respond to claims that any content violates the rights of third parties.  \n   iv. Protect the rights, property, or personal safety of the Company, its users, or the public.\n**Contact Us**\n\nIf you have any questions about these Terms, please contact us at [contact email].\n\nBy using the App, you acknowledge that you have read, understood, and agree to be bound by these Terms.',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.readexPro(
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
