// Export pages
export '/sruthi/usersignin/usersignin_widget.dart' show UsersigninWidget;
export '/sruthi/usercreateaccount/usercreateaccount_widget.dart'
    show UsercreateaccountWidget;
export '/maria/blogs/blogs_widget.dart' show BlogsWidget;
export '/maria/blogs1/blogs1_widget.dart' show Blogs1Widget;
export '/maria/blogs2/blogs2_widget.dart' show Blogs2Widget;
export '/maria/blogs3/blogs3_widget.dart' show Blogs3Widget;
export '/maria/blogs4/blogs4_widget.dart' show Blogs4Widget;
export '/maria/news/news_widget.dart' show NewsWidget;
export '/maria/news1/news1_widget.dart' show News1Widget;
export '/maria/news2/news2_widget.dart' show News2Widget;
export '/maria/news3/news3_widget.dart' show News3Widget;
export '/maria/news4/news4_widget.dart' show News4Widget;
export '/manya/profile/profile_widget.dart' show ProfileWidget;
export '/manya/editprofile1/editprofile1_widget.dart' show Editprofile1Widget;
export '/manya/support/support_widget.dart' show SupportWidget;
export '/manya/notifications/notifications_widget.dart'
    show NotificationsWidget;
export '/manya/eventhistory/eventhistory_widget.dart' show EventhistoryWidget;
export '/manya/tos/tos_widget.dart' show TosWidget;
export '/priyanka/protocol_event/protocol_event_widget.dart'
    show ProtocolEventWidget;
export '/priyanka/pentagramevent/pentagramevent_widget.dart'
    show PentagrameventWidget;
export '/priyanka/registrationform/registrationform_widget.dart'
    show RegistrationformWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/home_copy/home_copy_widget.dart' show HomeCopyWidget;
export '/priyanka/eventlist_copy/eventlist_copy_widget.dart'
    show EventlistCopyWidget;
export '/priyanka/ieeeevent_copy/ieeeevent_copy_widget.dart'
    show IeeeeventCopyWidget;
export '/priyanka/event_reg_page/event_reg_page_widget.dart'
    show EventRegPageWidget;
export '/sruthi/admingallery/admingallery_widget.dart' show AdmingalleryWidget;
export '/sruthi/photos1/photos1_widget.dart' show Photos1Widget;
export '/merch/list/list_widget.dart' show ListWidget;
export '/merch/cart/cart_widget.dart' show CartWidget;
export '/pages/adminhome/adminhome_widget.dart' show AdminhomeWidget;
export '/merch/payment/payment_widget.dart' show PaymentWidget;
export '/merch/paymentsucessful/paymentsucessful_widget.dart'
    show PaymentsucessfulWidget;
export '/merch/paymenfailed/paymenfailed_widget.dart' show PaymenfailedWidget;
export '/priyanka/eventlist_copy_copy/eventlist_copy_copy_widget.dart'
    show EventlistCopyCopyWidget;
export '/sruthi/usergallery/usergallery_widget.dart' show UsergalleryWidget;
export '/merch/cart1/cart1_widget.dart' show Cart1Widget;
export '/merch/merchlist/merchlist_widget.dart' show MerchlistWidget;
export '/merch/pay/pay_widget.dart' show PayWidget;
export '/removecart/removecart_widget.dart' show RemovecartWidget;
export '/merch/paymentmethods/paymentmethods_widget.dart'
    show PaymentmethodsWidget;
export '/card_payment/card_payment_widget.dart' show CardPaymentWidget;
